<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}

.container{
  width: 50%;
  content: "";
  display: table;
  clear: both;
  margin-left: 440px;

}

</style>
</head>
<body style="background-image: linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)), url(img2.jpg);">  

<h1 style="text-align: center; color:  #4bc970;">Ticket Booking</h1>
<br><br>
<div style="text-align: center; height: 300px;  width: 450px;" class="container">
<form method="post" action="insert.php">  
  <input type="text" placeholder="Name" name="name" style="height: 40px; width: 500px; border-radius: 5px; font-size: 1.3em;">
  
  <br><br><br><br>
  <input type="text" placeholder="Email" name="email" style="height: 40px; width: 500px; border-radius: 5px; font-size: 1.3em;">
  
  <br><br><br><br>
  <div style="font-size: 1.9em; color: #FFF">
  <label>Ticket Count</label>
             <select name="select" style="font-size: 0.7em;" >
               <option value = "1">1</option>
               <option value = "2">2</option>
               <option value = "3">3</option>
               <option value = "4">4</option>
             </select>
    </div>         
             <br><br><br><br>
   <div style="font-size: 1.9em; color: #FFF">          
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender">Other  
  </div>
  <br><br><br>
  
    <a href="#" class="hover">
  <button type="submit" name="Book" value="Book Ticket" style="height: 40px; width: 500px; border-radius: 5px; font-size: 1.3em; background-color: #4bc970; border: 1px solid #3ac162; color: #FFF;"> Book Ticket</button> 
  </a>
</form>
</div>


<?php
if (isset($_POST['Book'])) {

$name = $_POST['name'];
if (strlen($name <=8)) {
  echo "Name should we more than 8 character";
}
}
?>

</body>
</html>