<?php
echo "<h2>Your Data:</h2>";
$name = $_POST["name"];
echo "<br> <br>";
$email = $_POST["email"];
echo "<br> <br>";
$select = $_POST["select"];
echo "<br> <br>";
$gender = $_POST["gender"];

$con = mysqli_connect('localhost', 'root', '','insertdb');

$query = "INSERT INTO `userdata`( `name`, `email`, `select`, `gender`) VALUES ('$name', '$email' , 'select'
, '$gender')";

$run = mysqli_query($con, $query);

if ($run == TRUE) 
	echo "Data inserted successfully";

else 
	echo "Error";

?>