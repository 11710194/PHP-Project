<?php
echo "<h2>Your Data:</h2>";

$username = $_POST["username"];
echo "<br> <br>";

$password = $_POST["password"];

$con = mysqli_connect('localhost', 'root', '','login');

$query = "INSERT INTO `user`( `Username`, `Password`) VALUES ('$username','$password')";

$run = mysqli_query($con, $query);

if ($run == TRUE) 
	echo "successfully Login!";
else 
	echo "Error";
?>