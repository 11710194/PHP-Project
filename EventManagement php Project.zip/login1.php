

<html>
<head>
    <title>  Login page </title>
     
<style>
body{
    margin: 0;
    padding: 0;
    background: url(kv1.jpg);
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
}
.login-box{
    width: 500px;
    height: 420px;
    background: rgba(0, 1, 0, 0.5);
    color: #FFF;
    top: 50%;
    left: 50%;
    position: fixed;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 50px 30px;
}
.avatar{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
}
h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}
.login-box p{
    margin: 0;
    padding: 0;
    font-weight: bold;
}
.login-box input{
    width: 100%;
    margin-bottom: 20px;
}
.login-box input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #FFE;
    background: transparent;
    outline: none;
    height: 40px;
    color: #FFE;
    font-size: 16px;
}
.login-box input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background: #1c8adb;
    color: #FFE;
    font-size: 18px;
    border-radius: 20px;
}
.login-box input[type="submit"]:hover
{
    cursor: pointer;
    background: #39dc79;
    color: #000;
}

.login-box a{
    text-decoration: none;
    font-size: 14px;
    color: #fff;
}
.login-box a:hover
{
    color: #FA8072;
}


</style>
	
</head>
    <body>
    <div class="login-box">
        <h1>Sign in</h1>
            <form action="login.php" method="post">
                
            <p>Username</p>
            <input type="text" name="username" placeholder="">
            <p>Password</p>
            <input type="password" name="password" placeholder="">
            <input type="submit" name="submit" value="Login">
            <a href="#">Forget Password/</a>
            <a href="#">sign up</a>    
            </form>
        </div>
    
    </body>
</html>