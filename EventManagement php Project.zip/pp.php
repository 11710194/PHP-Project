<?php
echo "<h2>Your Data:</h2>";
$name = $_POST["name"];
echo "<br> <br>";
$email = $_POST["email"];
echo "<br> <br>";
$gender = $_POST["gender"];

$con = mysqli_connect('localhost', 'root', '','practice');

$query = "INSERT INTO `user`( `name`, `email`, `gender`) VALUES ('$name', '$email', '$gender')";

$run = mysqli_query($con, $query);

if ($run == TRUE) 
  echo "Data inserted successfully";

else 
  echo "Error";

?>